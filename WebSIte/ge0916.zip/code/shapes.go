// Methods and and interfaces
// See the io package for a good example on how to use interfaces
package main

import (
	"fmt"
	"math"
)

// Circle is a 2D circular shape
type Circle struct {
	X, Y   float64
	Radius float64
}

// Area returns the circle area
func (c *Circle) Area() float64 {
	// c is the reciever. We usually use pointer recievers
	return math.Pi * c.Radius * c.Radius
}

// Move moves the circle to a new location
func (c *Circle) Move(dx, dy float64) {
	c.X += dx
	c.Y += dy
}

// Rectangle is a squarish thingie
type Rectangle struct {
	X1, Y1, X2, Y2 float64
}

// Area returns the rectangle area
func (r *Rectangle) Area() float64 {
	dx := math.Abs(r.X1 - r.X2)
	dy := math.Abs(r.Y1 - r.Y2)
	return dx * dy
}

// Move moves the rectangle
func (r *Rectangle) Move(dx, dy float64) {
	r.X1 += dx
	r.X2 += dx
	r.Y1 += dy
	r.Y2 += dy
}

// Shape interface
type Shape interface {
	Move(dx, dy float64)
	Area() float64
}

// We don't have "implements" in Go. Every sturct that have the matching
// methods automaticall satisfies the interface

func main() {
	c := &Circle{1, 2, 10}
	fmt.Printf("%#v\n", c)
	fmt.Printf("area = %f\n", c.Area())

	// works also on object (not pointer)
	c2 := Circle{1, 2, 100}
	fmt.Printf("area = %f\n", c2.Area())

	c.Move(1, -17)
	fmt.Printf("%#v\n", c)

	r := &Rectangle{X1: 1, Y1: 1, X2: 4, Y2: 4}
	fmt.Println(r.Area())

	// Both *Circle and *Rectangle satisfy Shape
	shapes := []Shape{c, r, &c2}
	for _, s := range shapes {
		fmt.Println(s.Area())
	}
}
