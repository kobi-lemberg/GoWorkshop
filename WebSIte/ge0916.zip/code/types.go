// varibles
package main

import "fmt"

var (
	pi = 3.14 // global variable (to module)
)

func main() {
	var i int // initialzed to zero value
	fmt.Println(i)

	j := 17 // type inferred from right side of :=
	fmt.Printf("%d %T\n", j, j)

	f := 3.14 // float64
	fmt.Printf("%f %T\n", f, f)

	// var f1 float32 = 3.14

	// require explicit casting
	a := float64(j) + f
	fmt.Println(a)

	// This is a comment

	/* this is a multi
	line
	comment
	*/

	// Can assign several variables in one line
	s, t := "hello", "there"
	fmt.Printf("%s %s %T\n", s, t, s)

	x := 1
	y := "1"
	// Use %q to view the type
	fmt.Printf("x=%d y=%q\n", x, y)
	fmt.Printf("x=%v y=%v\n", x, y)

	// strings are unicode
	hi := "שלום"
	fmt.Printf("%s %d\n", hi, len(hi)) // len in bytes, not runes
	c := hi[0]                         // byte
	fmt.Printf("%v %T\n", c, c)
}
