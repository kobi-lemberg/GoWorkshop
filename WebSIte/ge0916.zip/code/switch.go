// Example of switch statement
package main

import (
	"fmt"
	"math/rand"
	"time"
)

func main() {
	rand.Seed(time.Now().Unix())
	loons := []string{"bugs", "tweety", "elmer"}

	winner := loons[rand.Intn(len(loons))]
	switch winner {
	case "bugs":
		fmt.Println("What's up, Doc?")
		// break is the default. Use fallthrough to get C behaviour
	case "tweety":
		fmt.Println("I Tawt I Taw a Puddy Cat")
	case "elmer":
		fmt.Println("I'm Hunting Wabbits")
		/*
			default:
				fmt.Println("oops")
		*/
	}

	winner = loons[rand.Intn(len(loons))]
	switch {
	case winner == "bugs":
		fmt.Println("What's up, Doc?")
	case winner == "tweety":
		fmt.Println("I Tawt I Taw a Puddy Cat")
	case winner == "elmer":
		fmt.Println("I'm Hunting Wabbits")
	}
}
