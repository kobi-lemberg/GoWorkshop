// word count - get a file (or stdin) and print number of lines, words, bytes
// (like *nix "wc" command)
package main

import (
	"flag"
	"fmt"
	"io"
	"log"
	"os"
)

// use const to create constants
const (
	space   = ' '
	newline = '\n'
	tab     = '\t'
)

// init is called explictly. Order of several init is not defined
func init() {
	// Usage function
	flag.Usage = func() {
		fmt.Fprintf(os.Stderr, "usage: wc [FILE]\n")
		flag.PrintDefaults()
	}
}

func main() {
	flag.Parse()
	if flag.NArg() > 1 {
		fmt.Fprintf(os.Stderr, "error: wrong number of arguments")
		os.Exit(1)
	}

	// We define these here so we can use them after the if block
	var file *os.File
	var fileName string
	var err error
	if flag.NArg() == 0 {
		file = os.Stdin
		fileName = "<stdin>"
	} else {
		fileName = flag.Arg(0)
		if file, err = os.Open(fileName); err != nil {
			log.Fatal(err)
		}
		defer file.Close()
	}

	lines, words, bytes, err := wc(file)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Printf("%d %d %d %s\n", lines, words, bytes, fileName)
}

// wc returns number of lines, words and bytes in rdr
func wc(rdr io.Reader) (int, int, int, error) {
	var lines, words, bytes int
	buf := make([]byte, 1024) // allocate 1k buffer
	inWord := false
	for {
		n, err := rdr.Read(buf)
		if err != nil {
			if err == io.EOF {
				break
			} else {
				return 0, 0, 0, err
			}
		}
		for i := 0; i < n; i++ {
			bytes++
			switch buf[i] {
			case newline:
				lines++
				inWord = false
			case tab, space:
				inWord = false
			default:
				if !inWord {
					inWord = true
					words++
				}

			}
		}
	}
	return lines, words, bytes, nil
}
