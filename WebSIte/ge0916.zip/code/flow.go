// Flow control (if and for) example
package main

import (
	"fmt"
	"os"
)

func main() {
	a := 1

	// No need for () around condition
	if a > 0 {
		fmt.Println("a > 0")
	}

	// else example
	var b int
	if a > 7 {
		fmt.Println("a > 7")
		b := 10 // b is local scope
		fmt.Println("b =", b)
	} else {
		fmt.Println("a <= 7")
		b := 20 // b is local scope
		fmt.Println("b =", b)
	}
	fmt.Println("b =", b) // b from line 18

	// && is logical and
	if a > 0 && b == 0 {
		fmt.Println("condition met")
	}

	// can't do
	// if a { ... }

	// We can use assignment and condition in one line
	if file, err := os.Open("/dev/null"); err != nil {
		fmt.Println("error: can't open")
	} else {
		fmt.Println("opened ", file.Name())
	}

	// Regular for loop
	for i := 0; i < 3; i++ {
		fmt.Println(i)
	}

	// while
	i := 0
	for i < 3 {
		fmt.Println(i)
		i++
	}

	i = 0
	// while(TRUE)
	for {
		if i > 3 {
			break
		}
		fmt.Println(i)
		i++
	}

	s := "hello = שלום"
	// range with single value -> indices
	for c := range s {
		fmt.Println(c)
	}

	// range with double value -> index, item
	// workes on runes
	for i, c := range s {
		fmt.Println(i, c, string(c))
	}

	// for each
	for _, c := range s {
		fmt.Println(c)
	}
}
