// defer exmaple
package main

import "fmt"

func main() {
	// defer happen in reverse order
	defer fmt.Println(1)
	defer fmt.Println(2)
	fmt.Println("In main")
	defer fmt.Println(3)
	defer func() {
		fmt.Println("a")
		fmt.Println("b")
	}()
}
