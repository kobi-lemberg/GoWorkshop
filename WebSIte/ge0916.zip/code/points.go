// struct example
package main

import "fmt"

// Reminder: Names starting with upper case letter are exported (visible
// outside the package)

// Point is a 2D point
type Point struct {
	X float64
	Y float64
}

func main() {
	// Create point struct. Fields initialized with zero values
	var p Point
	fmt.Printf("%v %T\n", p, p)
	fmt.Printf("%+v %T\n", p, p) // %+v show fields
	fmt.Printf("%#v %T\n", p, p) // %#v shows type and fields

	// Assign to field
	p.Y = 17
	fmt.Printf("%+v\n", p)

	// Create point with explicit values
	p1 := Point{1, 2}
	fmt.Printf("%+v\n", p1)
	// Create with fields by name
	p2 := Point{Y: 10, X: 20}
	fmt.Printf("%+v\n", p2)

	// Pointer th Point (by reference, there's no pointer arithmetic in Go)
	var pp *Point
	fmt.Printf("%#v\n", pp)
	// pp.X = 7 // panic

	pp = &p2
	fmt.Printf("%#v\n", pp)

	// Create new point, we seldom use "new"
	pp2 := new(Point)
	fmt.Printf("%#v\n", pp2)

	// Create new point
	pp3 := &Point{1, 2}
	fmt.Printf("%#v\n", pp3)

	// Constructors are just function starting with New (or just New)
	pp4 := NewPoint(7, 8)
	fmt.Printf("%#v\n", pp4)

	if pp4 == pp4 {
		fmt.Println("same same")
	}
}

// NewPoint create a new point with x and y coordinates
func NewPoint(x, y float64) *Point {
	return &Point{x, y}
}
