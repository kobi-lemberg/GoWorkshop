// arrays and slices
package main

import "fmt"

func main() {
	var arr [10]int                   // Create array, allocated in memory
	fmt.Printf("%v - %T\n", arr, arr) // Size if part of type
	// we rearly use arrays in Go

	s := arr[1:3] // slice is a view on part of array
	fmt.Printf("%v len=%d cap=%d type=%T\n", s, len(s), cap(s), s)
	// fmt.Println(s[4]) // panic, can't get out of slice

	arr[2] = 17
	fmt.Println(s) // slice is showing changes in underlying array

	var a []int // slice
	fmt.Println(a, len(a))
	// fmt.Println(a[0]) // panic

	b := make([]int, 3) // allocate slice
	fmt.Printf("%v len=%d cap=%d type=%T\n", b, len(b), cap(b), b)

	c := []int{1, 2, 3} // syntax for creating a slice
	fmt.Printf("%v len=%d cap=%d type=%T\n", c, len(c), cap(c), c)

	var d []int
	for i := 0; i < 10; i++ {
		d = append(d, i) // Add element to slice, underlying array will grow if needed
		fmt.Printf("%v len=%d cap=%d type=%T\n", d, len(d), cap(d), d)
	}
	fmt.Println(d[3]) // 0 based

	cs := []string{"a", "b", "c"}
	for i, val := range cs {
		fmt.Printf("%s at %d\n", val, i)
	}

}
