// Simple HTTP server. Run then visit http://localhost:8080
package main

import (
	"fmt"
	"net/http"
)

// handler handles requests
func handler(w http.ResponseWriter, r *http.Request) {
	fmt.Fprintf(w, "Hello GE\n")
}

func main() {
	http.HandleFunc("/", handler)     // routing. map / to handler
	http.ListenAndServe(":8080", nil) // run web server on port 8080
}
