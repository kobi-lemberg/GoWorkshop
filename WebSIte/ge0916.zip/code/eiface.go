// The empty interface
package main

import "fmt"

func main() {
	var i interface{} // empty interface, everything implements it

	i = 7
	fmt.Printf("%v - %T\n", i, i)

	i = "hello"
	fmt.Printf("%v - %T\n", i, i)

	// from interface to concerte type
	s := i.(string)
	fmt.Printf("%v - %T\n", s, s)

	// This will panic
	/*
		j := i.(int)
		fmt.Printf("%v - %T\n", j, j)
	*/

	j, ok := i.(int)
	if ok {
		fmt.Printf("int = %d", j)
	} else {
		fmt.Println("not an int")
	}

	// type switch
	switch i.(type) {
	case int:
		fmt.Println("an integer")
	case string:
		fmt.Println("a string")
	default:
		fmt.Printf("unknown type %T\n", i)
	}
}
