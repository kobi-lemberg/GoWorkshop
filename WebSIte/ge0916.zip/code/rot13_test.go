// Testing rot13
/* Commands:

	# Run all tests
    go test

	# Run all tests in verbose mode
    go test -v

	# Run single test (regular expression)
    go test -v -run TestRot13

	# Run tests and bencharks
    go test -v -bench .

	# Run only benchmarks
    go test -v -run XXX -bench .

	# Generate coverage
    go test -v -coverprofile=/tmp/test.cover
    go tool covert -html=/tmp/test.cover
*/
package rot13

import "testing"

// Simple test
func TestRot13(t *testing.T) {
	orig := "Hello There"
	expected := "Uryyb Gurer"

	t.Logf("checking %q", orig)
	out := Rot13(orig)
	if out != expected {
		// t.Fatal and friends will stop all tests
		t.Fatalf("%q != %q", out, expected)
	}
}

// Table drive testing - test one function with various input
type TestCase struct {
	in       string
	expected string
}

var testCases = []TestCase{
	{"", ""},
	{"Forever 21", "Sberire 21"},
}

func checkRot13(t *testing.T, in, expected string) {
	// go 1.6
	// t.Logf("checking %q", in)
	out := Rot13(in)
	if out != expected {
		// t.Error and friends will mark fail but will continue other tests
		t.Errorf("in = %q, out=%q, expected=%q", in, out, expected)
	}
}

func TestManyRot13(t *testing.T) {
	// Setup
	for _, tc := range testCases {
		// go 1.6
		//checkRot13(t, tc.in, tc.expected)

		// go 1.7
		t.Run(tc.in, func(t *testing.T) { checkRot13(t, tc.in, tc.expected) })
	}
	// Teardown
}

// Benchmark
func BenchmarkRot13(b *testing.B) {
	// b.N is adjusted by the test suite
	for i := 0; i < b.N; i++ {
		Rot13("The answer is 42")
	}
}

// Parallel tests
func TestParallel1(t *testing.T) {
	t.Parallel() // mark test as parallel
	t.Logf("running parallel1")
}

func TestParallel2(t *testing.T) {
	t.Parallel() // mark test as Parallel
	t.Logf("running parallel1")
}
