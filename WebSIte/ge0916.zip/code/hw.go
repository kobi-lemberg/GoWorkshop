// Initial hello world
package main // Every go code goes inside a package

import "fmt" // Import "fmt" from standard library

func main() { // main used when creating executable
	fmt.Println("Hello GE")
}
