// maps example
package main

import "fmt"

func main() {
	var ages map[string]int // define map type keys are strings, values are ints
	fmt.Printf("%v (len=%d) %T\n", ages, len(ages), ages)

	age := ages["daffy"] // can access nil map, get zero value if not found
	fmt.Println(age)

	// ages["daffy"] = 80 // panic on assigment to nil map

	ages = make(map[string]int) // allocate memory for a map
	ages["daffy"] = 80          // panic on assigment to nil map
	age = ages["daffy"]
	fmt.Println(age)

	// access with two variables -> value and found
	if age, found := ages["bugs"]; !found {
		fmt.Println("bugs not fond")
	} else {
		fmt.Printf("bugs is %d years old", age)
	}

	// Create map explictly with values
	colors := map[string]string{
		"bugs":   "gray",
		"tweety": "yellow",
		"daffy":  "black",
		"taz":    "brown", // last comma is mandatory
	}

	// Go over keys
	for name := range colors {
		fmt.Println(name)
	}

	// Go over keys and values
	for name, color := range colors {
		fmt.Printf("%s is %s\n", name, color)
	}

	fmt.Println(len(colors))
	// Delete from map
	delete(colors, "taz")
	fmt.Println(len(colors))
}
