// HTTP configuration server

/*
- Initially reads a YAML file
- GET /_all to get all keys
- GET /key to get a key
- POST /key to set key from request body (up to 1K)
- GET /debug/vars for metrics (from expvar)
*/

package main

import (
	"bytes"
	"expvar"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"sync"

	yaml "gopkg.in/yaml.v1"
)

var (
	lock   sync.Mutex             // map lock
	conf   map[string]interface{} // configuration
	hits   *expvar.Int            // number of hits (in /debug/vars)
	errors *expvar.Int            // number of errors (in /debug/vars)
)

// Request handler
func handler(w http.ResponseWriter, r *http.Request) {
	lock.Lock()
	defer lock.Unlock()

	hits.Add(1)

	key := r.URL.Path[1:] // trim / prefix
	switch r.Method {
	case "GET":
		if key == "_all" {
			for key, value := range conf {
				fmt.Fprintf(w, "%s=%v\n", key, value)
			}
			return
		}
		val, ok := conf[key]
		if !ok {
			errors.Add(1)
			http.Error(w, fmt.Sprintf("%q not found", key), http.StatusNotFound)
			return
		}
		fmt.Fprintf(w, "%v\n", val)
	case "POST":
		defer r.Body.Close()
		var buf bytes.Buffer
		// Limit size to 1K
		io.Copy(&buf, io.LimitReader(r.Body, 1024))
		val := buf.String()
		if len(val) == 0 {
			errors.Add(1)
			http.Error(w, "empty body", http.StatusBadRequest)
			return
		}
		conf[key] = val
	default:
		errors.Add(1)
		http.Error(w, "invalid method", http.StatusMethodNotAllowed)
		return
	}
}

// loadConfig loads configuration from YAML
func loadConfig(path string) (map[string]interface{}, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	buf, err := ioutil.ReadAll(file)
	if err != nil {
		return nil, err
	}

	var conf map[string]interface{}
	if err := yaml.Unmarshal(buf, &conf); err != nil {
		return nil, err
	}

	return conf, nil

}

func init() {
	// metrics
	hits = expvar.NewInt("Hits")
	errors = expvar.NewInt("Errors")
}

func main() {
	var err error
	conf, err = loadConfig("config.yml")
	if err != nil {
		log.Fatal(err)
	}
	http.HandleFunc("/", handler)
	log.Fatal(http.ListenAndServe(":8080", nil))
}
