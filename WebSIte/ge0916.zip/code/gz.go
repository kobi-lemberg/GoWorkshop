// gz compression
package main

import (
	"compress/gzip"
	"io"
	"log"
	"os"
)

func main() {
	in, err := os.Open("innocents-abroad.txt")
	if err != nil {
		log.Fatalf("can't open - %s", err)
	}
	defer in.Close()

	out, err := os.Create("innocents-abroad.txt.gz")
	if err != nil {
		log.Fatalf("can't create - %s", err)
	}
	defer out.Close()

	// Wrap out with gz writer
	gz := gzip.NewWriter(out)
	defer gz.Close()

	// Pass the gz writer to io.Copy
	_, err = io.Copy(gz, in)
	if err != nil {
		log.Fatalf("can't compress - %s", err)
	}
}
