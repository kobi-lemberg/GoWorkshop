// Convert numeric grades in CSV to ABCDF
package main

import (
	"encoding/csv"
	"fmt"
	"io"
	"log"
	"os"
	"strconv"
)

var (
	names   = []string{"A", "B", "C", "D", "F"}
	cutoffs = []int{90, 80, 70, 60, 0}
	grades  map[int]string // 92 -> "A"
)

func init() {
	// Create and fill grades map
	grades = make(map[int]string)
	high := 100
	for i, name := range names {
		for score := high; score >= cutoffs[i]; score-- {
			grades[score] = name
		}
		high = cutoffs[i] - 1
	}
}

func main() {
	file, err := os.Open("grades.csv")
	if err != nil {
		log.Fatal(err)
	}
	defer file.Close()

	rdr := csv.NewReader(file)
	for {
		// row is a slice of strings
		row, err := rdr.Read()
		if err == io.EOF {
			break
		}
		if err != nil {
			log.Fatal(err)
		}
		// convert grade string to number
		grade, err := strconv.Atoi(row[1])
		if err != nil {
			log.Fatal(err)
		}
		fmt.Printf("%-10s -> %s\n", row[0], grades[grade])
	}
}
