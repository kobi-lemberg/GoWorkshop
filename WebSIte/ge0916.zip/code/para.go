// Example on goroutines and channels
package main

import (
	"fmt"
	"time"
)

func Print(i int) {
	time.Sleep(100 * time.Millisecond)
	fmt.Println(i)
}

func main() {
	// Simple invocation of goroutine
	for i := 0; i < 5; i++ {
		go Print(i)
	}

	// Bad scoping, will print 5 all the time
	for i := 0; i < 5; i++ {
		go func() {
			fmt.Println(i)
		}()
	}

	// Fix to the above: Pass parameter
	for i := 0; i < 5; i++ {
		go func(n int) {
			fmt.Println(n)
		}(i)
	}

	ch := make(chan int) // unbuffered channel
	go func() {
		ch <- 7 // push item to channel, if we do it outside a goroutine we'll block
	}()

	i := <-ch // get from channel

	fmt.Printf("got %d\n", i)

	bch := make(chan int, 10) // buffered channel
	bch <- 17                 // will not block until channel is full
	fmt.Printf("len=%d, cap=%d\n", len(bch), cap(bch))
	j := <-bch
	fmt.Printf("got %d\n", j)

	for a := 10; a < 15; a++ {
		bch <- a
	}

	// Make sure to close the channel so the for loop below won't block
	go func() {
		time.Sleep(100 * time.Millisecond)
		close(bch)
	}()

	for b := range bch {
		fmt.Println(b)
	}

	// Generate and close
	// We need to make sure we're not leaking goroutines
	ch1 := make(chan string)
	go func() {
		for i := 0; i < 5; i++ {
			ch1 <- fmt.Sprintf("message #%d", i)
		}
		close(ch1)
	}()
	for s := range ch1 {
		fmt.Println(s)
	}

	// Use select for few channels
	ch2 := make(chan bool)
	ch3 := make(chan string)
	go func() {
		time.Sleep(50 * time.Millisecond)
		ch2 <- true
	}()
	select {
	case s := <-ch3:
		fmt.Println("got from ch3", s)
	case v := <-ch2:
		fmt.Println("got from ch2", v)
	case <-time.After(100 * time.Millisecond):
		fmt.Println("timeout")
		/*
			default: // happend when there's no data in any channel
				fmt.Println("no value")
		*/
	}

	for i := range produce() {
		fmt.Println(i)
	}
}

// produce items on channel
// be careful not to leak goroutines. This is usually done with passing a
// cancellation channel to the producer. See https://golang.org/pkg/context/ as well
func produce() chan int {
	ch := make(chan int)
	go func() {
		for i := 0; i < 3; i++ {
			ch <- i
		}
		close(ch) // signal we're done
	}()
	return ch
}
